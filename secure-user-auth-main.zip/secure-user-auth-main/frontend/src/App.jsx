import { Routes, Route, Navigate } from "react-router-dom";
import { useContext } from "react";
import { AuthContext } from "./AuthContext";
import Navbar from "./components/Navbar";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import UserDetail from "./pages/UserDetail";
import About from "./pages/About";
import Contact from "./pages/Contact";

function App() {
  const { auth } = useContext(AuthContext);

  return (
    <>
      <Navbar />
      <Routes>
        {!auth && (
          <>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
          </>
        )}
        {auth && (
          <>
            <Route path="/user-detail" element={<UserDetail />} />
            <Route path="/dashboard" element={<Dashboard />} />
          </>
        )}
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="*" element={<Navigate to={auth ? "/user-detail" : "/login"} />} />
      </Routes>
    </>
  );
}

export default App;
