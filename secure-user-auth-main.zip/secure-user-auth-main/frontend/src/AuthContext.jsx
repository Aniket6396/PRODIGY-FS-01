import { createContext, useEffect, useState } from "react";
import { isAuthenticated } from "./auth";

export const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [auth, setAuth] = useState(isAuthenticated());

  useEffect(() => {
    
    const interval = setInterval(() => {
      setAuth(isAuthenticated());
    }, 500);
    return () => clearInterval(interval);
  }, []);

  return (
    <AuthContext.Provider value={{ auth, setAuth }}>
      {children}
    </AuthContext.Provider>
  );
}
