export const isAuthenticated = () => {
  const token = localStorage.getItem('token');
  return !!token;
};

export const getUserFromToken = () => {
  const token = localStorage.getItem('token');
  if (!token) return null;

  const payload = token.split('.')[1];
  return JSON.parse(atob(payload));
};

export const logout = () => {
  localStorage.removeItem('token');
};
