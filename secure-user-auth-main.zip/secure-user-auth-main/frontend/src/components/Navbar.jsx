import { Link, useNavigate } from 'react-router-dom';
import { getUserFromToken } from '../auth';
import { useEffect, useState, useContext } from 'react';
import { AuthContext } from '../AuthContext';

function Navbar() {
  const { auth } = useContext(AuthContext);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (auth) {
      setUser(getUserFromToken());
    } else {
      setUser(null);
    }
  }, [auth]);

  const handleLogout = () => {
    localStorage.removeItem("token");
    window.location.reload(); // Optional fallback
  };

  return (
    <nav style={styles.nav}>
      <h2 style={styles.logo}>AuthApp</h2>
      <div style={styles.links}>
        {!user && (
          <>
            <Link to="/login" style={styles.link}>Login</Link>
            <Link to="/register" style={styles.link}>Register</Link>
          </>
        )}
        {user && (
  <>
    <Link to="/user-detail" style={styles.link}>User Detail</Link>
    {user.role === 'admin' && (
      <Link to="/dashboard" style={styles.link}>Dashboard</Link>
    )}
  </>
)}

        <Link to="/about" style={styles.link}>About</Link>
        <Link to="/contact" style={styles.link}>Contact</Link>
      </div>
    </nav>
  );
}

const styles = {
  nav: {
    padding: '10px 20px',
    display: 'flex',
    justifyContent: 'space-between',
    backgroundColor: '#222',
    color: 'white'
  },
  logo: {
    margin: 0
  },
  links: {
    display: 'flex',
    gap: '15px',
    alignItems: 'center'
  },
  link: {
    color: 'white',
    textDecoration: 'none'
  },
  logout: {
    padding: '5px 10px',
    cursor: 'pointer',
    backgroundColor: '#f44336',
    color: 'white',
    border: 'none',
    borderRadius: '4px'
  }
};

export default Navbar;
