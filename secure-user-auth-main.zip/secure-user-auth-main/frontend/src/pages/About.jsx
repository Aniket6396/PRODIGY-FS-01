function About() {
  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2>About This App</h2>
        <p>This is a simple authentication system built using React (Vite) and Express.</p>
        <p>
          It supports user login, registration, route protection, JWT token handling,
          and role-based access for admin users.
        </p>
      </div>
    </div>
  );
}

const styles = {
  container: {
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
    padding: 20
  },
  card: {
    maxWidth: 600,
    backgroundColor: "#fff",
    padding: 30,
    borderRadius: 8,
    boxShadow: "0 0 10px rgba(0,0,0,0.1)",
    lineHeight: 1.6,
    marginBottom: 100
  }
};

export default About;
