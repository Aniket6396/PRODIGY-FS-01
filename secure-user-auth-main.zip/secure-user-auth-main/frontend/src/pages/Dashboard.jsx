import { getUserFromToken } from "../auth";
import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { API_BASE } from "../api";

function Dashboard() {
  const [users, setUsers] = useState([]);
  const navigate = useNavigate();
  const user = getUserFromToken();

  useEffect(() => {
    if (!user || user.role !== "admin") {
      navigate("/user-detail");
      return;
    }

    const fetchUsers = async () => {
      try {
        const res = await axios.get(`${API_BASE}/dashboard`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        setUsers(res.data.users);
      } catch (err) {
        alert("Unauthorized or failed to fetch users");
        navigate("/user-detail");
      }
    };

    fetchUsers();
  }, [user, navigate]);

  return (
    <div style={styles.container}>
      <h2 style={styles.heading}>Admin Dashboard</h2>
      <table style={styles.table}>
        <thead>
          <tr>
            <th style={styles.th}>Username</th>
            <th style={styles.th}>Role</th>
          </tr>
        </thead>
        <tbody>
          {users.map((u, idx) => (
            <tr key={idx}>
              <td style={styles.td}>{u.username}</td>
              <td style={styles.td}>{u.role}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const styles = {
  container: {
    padding: "30px",
    backgroundColor: "#f0f0f0",
    minHeight: "100vh"
  },
  heading: {
    marginBottom: "20px",
    fontSize: "24px"
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    backgroundColor: "#fff"
  },
  th: {
    textAlign: "left",
    padding: "12px",
    backgroundColor: "#333",
    color: "white"
  },
  td: {
    padding: "10px",
    borderBottom: "1px solid #ccc"
  }
};

export default Dashboard;
