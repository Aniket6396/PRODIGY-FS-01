function Contact() {
  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2>Contact Us</h2>
        <p>📧 Email: support@authapp.com</p>
        <p>📞 Phone: +91-9845******</p>
        <p>🏢 Address: Haridwar, Uttarakhand, India</p>
      </div>
    </div>
  );
}

const styles = {
  container: {
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
    padding: 20
  },
  card: {
    maxWidth: 500,
    backgroundColor: "#fff",
    padding: 30,
    borderRadius: 8,
    boxShadow: "0 0 10px rgba(0,0,0,0.1)",
    lineHeight: 1.6,
    marginBottom: 100
  }
};

export default Contact;
