const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

const app = express();
const PORT = 5000;
const JWT_SECRET = 'secret_key';

app.use(cors());
app.use(bodyParser.json());

const users = []; 

// default admin 
(async () => {
  const hashedPassword = await bcrypt.hash('admin123', 10);
  users.push({ username: 'admin', password: hashedPassword, role: 'admin' });
  
})();



// Register Route
app.post('/register', async (req, res) => {
  const { username, password, role = "user" } = req.body;
  const existingUser = users.find(user => user.username === username);
  if (existingUser) return res.status(400).json({ message: "User already exists" });

  const hashedPassword = await bcrypt.hash(password, 10);
  users.push({ username, password: hashedPassword, role });
  res.status(201).json({ message: "User registered" });
});

// Login Route
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username);
  if (!user) return res.status(401).json({ message: "Invalid credentials" });

  const valid = await bcrypt.compare(password, user.password);
  if (!valid) return res.status(401).json({ message: "Invalid credentials" });

  const token = jwt.sign({ username: user.username, role: user.role }, JWT_SECRET, { expiresIn: "1h" });
  res.json({ token });
});

// Middleware for Protected Routes
const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.sendStatus(401);

  const token = authHeader.split(" ")[1];
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

// Dashboard Route - Only Admin
app.get('/dashboard', authenticate, (req, res) => {
  if (req.user.role !== 'admin') return res.sendStatus(403);
  res.json({ users }); // Admin can see all users
});

// User Detail Route - Any Logged-in User
app.get('/user', authenticate, (req, res) => {
  res.json({ user: req.user });
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
